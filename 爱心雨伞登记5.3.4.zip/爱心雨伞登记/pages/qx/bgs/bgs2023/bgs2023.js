// pages/qx/bgs/bgs2023/bgs2023.js
Page({
   //播放音乐函数
   player(audio){
    var that =this
    audio.title = '偏爱'
    audio.epname = '偏爱'
    audio.singer = '张芸京'
    audio.src = 'https://636c-cloud1-6g5n7d3da0d9860e-1313177812.tcb.qcloud.la/%E5%8A%9E%E5%85%AC%E5%AE%A4/%E5%81%8F%E7%88%B1.m4a?sign=23176dd42cdfd61828cabd4ed9ce5359&t=1672145668'

    audio.onEnded(()=>{
      that.player(wx.getBackgroundAudioManager())
    })


  },
  Click(){
    wx.navigateTo({
      url: '/pages/onlyone/onlyone',
    })
  },

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.player(wx.getBackgroundAudioManager())


  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.player(wx.getBackgroundAudioManager())


  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})