// pages/qx/rs/rs2023/rs2023.js
Page({

  //播放音乐函数
  player(audio){
    var that =this
    audio.title = '追光者'
    audio.epname = '追光者'
    audio.singer = '岑宁儿'
    audio.src = 'https://636c-cloud1-6g5n7d3da0d9860e-1313177812.tcb.qcloud.la/%E4%BA%BA%E4%BA%8B%E9%83%A8/%E8%BF%BD%E5%85%89%E8%80%85.m4a?sign=a2409340d39e4bb3ed5fe4112e8646f7&t=1672304435'

    audio.onEnded(()=>{
      that.player(wx.getBackgroundAudioManager())
    })


  },

  Click(){
    wx.navigateTo({
      url: '/pages/onlyone/onlyone',
    })
  },

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.player(wx.getBackgroundAudioManager())

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.player(wx.getBackgroundAudioManager())

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})